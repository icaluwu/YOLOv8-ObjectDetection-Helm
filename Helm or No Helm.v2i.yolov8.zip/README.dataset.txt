# Helm or No Helm > 2024-12-08 12:13pm
https://universe.roboflow.com/test-0f0mb/helm-or-no-helm

Provided by a Roboflow user
License: CC BY 4.0

